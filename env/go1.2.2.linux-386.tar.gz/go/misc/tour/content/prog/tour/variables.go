// +build OMIT

package main

import "fmt"

var i int
var c, python, java bool

func main() {
	fmt.Println(i, c, python, java)
}
